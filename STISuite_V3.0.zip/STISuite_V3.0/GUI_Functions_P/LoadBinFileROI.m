%  Wei Li, Duke University, June 2010
% control=0;
%
