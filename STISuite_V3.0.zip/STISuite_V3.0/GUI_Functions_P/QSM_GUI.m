%  Wei Li, Duke University, May 2010
%  Wei Li, Updated on 10/28/2010 to include 4D display functionality
% 
%
