%  hongjiang Wei, PhD
%  
%  Brain Imaging And Analysis Center, Duke Uiversity.
% % zeropadding to square matrix
%
