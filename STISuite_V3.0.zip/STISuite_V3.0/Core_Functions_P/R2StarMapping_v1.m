%  TE1, Echospacing are both in milli-seconds
%
