%  FFTNC   1D discrete Fourier Transform with FFT-shift.
% 
%  X = fftc(x,mrows,ncols)
% 
%  ####### Jian Zhang, jianz@stanford.edu, 08/13/2006 #######
%  Chunlei Liu, 08/2009
%  Wei Li, 10/28/2010
%
