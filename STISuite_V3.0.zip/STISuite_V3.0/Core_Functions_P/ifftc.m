%  IFFTNC   N-dimensional inverse discrete Fourier Transform with FFT-shift.
% 
%  X = ifftnc(x,siz)
% 
%  ####### Jian Zhang, jianz@stanford.edu, 08/11/2006 #######
%  Chunlei Liu, 08/2009
%  Wei Li, 2010
%
