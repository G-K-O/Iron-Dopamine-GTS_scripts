 function normalized = normalize_var(array, a,b)
          normalized = (b-a).*((array-min(array(:)))/(max(array(:)-min(array(:)))))+a;