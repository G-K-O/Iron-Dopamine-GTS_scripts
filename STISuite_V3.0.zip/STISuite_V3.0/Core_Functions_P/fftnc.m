%  im = fftnc(d)
% 
%  fftnc perfomrs a centered fftn
% 
%
