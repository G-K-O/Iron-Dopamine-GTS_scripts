%  im = ifftnc(d)
% 
%  ifftnc perfomrs a centered ifftn
% 
%
