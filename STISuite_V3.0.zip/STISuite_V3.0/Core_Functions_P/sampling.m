%  Wei Li, Duke Uiversity, May 5, 2012
% % zeropadding to square matrix
%
